package edu.uncg.mobileapps.csc495proj2;

import android.content.Intent;
import android.graphics.Typeface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Typeface fontfamily = Typeface.createFromAsset(getAssets(), "fonts/fontawesome.ttf");


    }

    public void startVolume(View view){
        Intent volumeIntent = new Intent(this, VolumeActivity.class);
        startActivity(volumeIntent);
    }

    public void startLength(View view){
        Intent lengthIntent = new Intent(this, LengthActivity.class);
        startActivity(lengthIntent);
    }

    public void startMass(View view){
        Intent massIntent = new Intent(this, MassActivity.class);
        startActivity(massIntent);
    }
}
