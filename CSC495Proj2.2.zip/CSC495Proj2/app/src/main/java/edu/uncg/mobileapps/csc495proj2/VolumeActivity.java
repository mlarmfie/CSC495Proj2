package edu.uncg.mobileapps.csc495proj2;

import android.content.Context;
import android.content.SharedPreferences;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Vibrator;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import javax.measure.Measure;
import javax.measure.converter.UnitConverter;
import javax.measure.quantity.Volume;
import javax.measure.unit.NonSI;
import javax.measure.unit.Unit;

import static javax.measure.unit.NonSI.CUBIC_INCH;
import static javax.measure.unit.NonSI.FOOT;
import static javax.measure.unit.NonSI.GALLON_LIQUID_US;
import static javax.measure.unit.NonSI.INCH;
import static javax.measure.unit.NonSI.LITER;
import static javax.measure.unit.NonSI.MILE;
import static javax.measure.unit.NonSI.OUNCE_LIQUID_US;
import static javax.measure.unit.NonSI.YARD;
import static javax.measure.unit.SI.CENTIMETER;
import static javax.measure.unit.SI.KILOMETER;
import static javax.measure.unit.SI.METER;
import static javax.measure.unit.SI.MILLIMETER;

public class VolumeActivity extends AppCompatActivity implements OnItemSelectedListener, SensorEventListener {
    Spinner volumeSpinner1;
    Spinner volumeSpinner2;
    String spinner1Value;
    String spinner2Value;
    String answer;

    private float lastX, lastY, lastZ;
    private SensorManager sensorManager;
    private Sensor accelerometer;
    private float deltaX = 0;
    private float deltaY = 0;
    private float deltaZ = 0;

    private float shakeThreshold = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_volume);
        getName();

        //Create spinners
        //Spinner 1
        volumeSpinner1 = (Spinner) findViewById(R.id.volumeSpinner1);
        ArrayAdapter<CharSequence> volumeAdapter1 = ArrayAdapter.createFromResource(this,
                R.array.volume_array, android.R.layout.simple_spinner_item);
        volumeAdapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        volumeSpinner1.setAdapter(volumeAdapter1);
        volumeSpinner1.setOnItemSelectedListener(this);


        //Spinner 2
        volumeSpinner2 = (Spinner) findViewById(R.id.volumeSpinner2);
        ArrayAdapter<CharSequence> volumeAdapter2 = ArrayAdapter.createFromResource(this,
                R.array.volume_array, android.R.layout.simple_spinner_item);
        volumeAdapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        volumeSpinner2.setAdapter(volumeAdapter2);
        volumeSpinner2.setOnItemSelectedListener(this);

        // Init sensorManager
        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        if (sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) != null) {
            // success! we have an accelerometer
            accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
            sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_NORMAL);
            shakeThreshold = accelerometer.getMaximumRange() / 2;
        } else {
            // fail we dont have an accelerometer!
        }
    }


    public void submitVolume(View view){
        spinner1Value = volumeSpinner1.getSelectedItem().toString();
        spinner2Value = volumeSpinner2.getSelectedItem().toString();

        EditText editTextValue1 = (EditText) findViewById(R.id.editText);
        CharSequence editValue1 = editTextValue1.getText();

        float editValueFloat = Float.parseFloat(editValue1.toString());

        Unit unit1 = getUnit(spinner1Value);
        Unit unit2 = getUnit(spinner2Value);

        UnitConverter value = unit1.getConverterTo(unit2);
        double answer = value.convert(Measure.valueOf(editValueFloat, unit1).doubleValue(unit1));
        String answerString = String.valueOf(answer);

        TextView answerView = (TextView) findViewById(R.id.answerViewVolume);
        answerView.setText(answerString);
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        parent.getItemAtPosition(position);
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        deltaX = Math.abs(lastX - event.values[0]);
        deltaY = Math.abs(lastY - event.values[1]);
        deltaZ = Math.abs(lastZ - event.values[2]);

        if (deltaX < 2)
            deltaX = 0;
        if (deltaY < 2)
            deltaY = 0;
        if (deltaZ < 2)
            deltaZ = 0;

        lastX = event.values[0];
        lastY = event.values[1];
        lastZ = event.values[2];
        shake();
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }

    @Override
    protected void onResume() {
        super.onResume();
        sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_NORMAL);
    }

    @Override
    protected void onPause() {
        super.onPause();
        sensorManager.unregisterListener(this);
    }

    public void shake() {
        if ((deltaX > shakeThreshold) || (deltaY > shakeThreshold) || (deltaZ > shakeThreshold)) {
            TextView answerView = (TextView) findViewById(R.id.answerViewVolume);
            answerView.setText("");

            EditText editTextValue1 = (EditText) findViewById(R.id.editText);
            editTextValue1.getText().clear();
        }
    }

    public void getName(){

        SharedPreferences sharedPrefs = getSharedPreferences("univertVolumePref", Context.MODE_PRIVATE);
        SharedPreferences.Editor ed;
        if(!sharedPrefs.contains("initialized")){
            ed = sharedPrefs.edit();


            //Indicate that the default shared prefs have been set
            ed.putBoolean("initialized", true);
            ed.commit();
        }else{
            //set other crap;
        }
    }

    public Unit getUnit(String spinnerValue){
        Unit unit = null;

        switch(spinnerValue){
            case "Gallon": unit = GALLON_LIQUID_US;
                break;
            case "Quart": unit = GALLON_LIQUID_US.divide(4L);
                break;
            case "Pint": unit = CUBIC_INCH.times(28.88);
                break;
            case "Cup": unit = CUBIC_INCH.times(14.65);
                break;
            case "Ounce": unit = OUNCE_LIQUID_US;
                break;
            case "Tablespoon": unit = CUBIC_INCH.times(0.902);
                break;
            case "Teaspoon": unit = CUBIC_INCH.times(0.301);
                break;
            case "Liter": unit = LITER;
                break;
        }
        return unit;
    }
}
