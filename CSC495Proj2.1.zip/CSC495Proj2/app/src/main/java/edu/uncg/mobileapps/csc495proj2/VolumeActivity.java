package edu.uncg.mobileapps.csc495proj2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

public class VolumeActivity extends AppCompatActivity {
    Spinner volumeSpinner1;
    Spinner volumeSpinner2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_volume);

        //Create spinners
        //Spinner 1
        volumeSpinner1 = (Spinner) findViewById(R.id.volumeSpinner1);
        ArrayAdapter<CharSequence> volumeAdapter1 = ArrayAdapter.createFromResource(this,
                R.array.volume_array, android.R.layout.simple_spinner_item);
        volumeAdapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        volumeSpinner1.setAdapter(volumeAdapter1);

        //Spinner 2
        volumeSpinner2 = (Spinner) findViewById(R.id.volumeSpinner2);
        ArrayAdapter<CharSequence> volumeAdapter2 = ArrayAdapter.createFromResource(this,
                R.array.volume_array, android.R.layout.simple_spinner_item);
        volumeAdapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        volumeSpinner2.setAdapter(volumeAdapter2);
    }

    public void submitVolume(View view){
        //calculate volume
    }
}
