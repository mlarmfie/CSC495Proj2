package edu.uncg.mobileapps.csc495proj2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

public class MassActivity extends AppCompatActivity {
    Spinner massSpinner1;
    Spinner massSpinner2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mass);

        //Create spinners
        //Spinner 1
        massSpinner1 = (Spinner) findViewById(R.id.massSpinner1);
        ArrayAdapter<CharSequence> massAdapter1 = ArrayAdapter.createFromResource(this,
                R.array.mass_array, android.R.layout.simple_spinner_item);
        massAdapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        massSpinner1.setAdapter(massAdapter1);

        //Spinner 2
        massSpinner2 = (Spinner) findViewById(R.id.massSpinner2);
        ArrayAdapter<CharSequence> massAdapter2 = ArrayAdapter.createFromResource(this,
                R.array.mass_array, android.R.layout.simple_spinner_item);
        massAdapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        massSpinner2.setAdapter(massAdapter2);
    }

    public void submitMass(View view){
        //Calculate Mass
    }
}
