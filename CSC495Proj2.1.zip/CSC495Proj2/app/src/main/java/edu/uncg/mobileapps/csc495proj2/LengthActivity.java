package edu.uncg.mobileapps.csc495proj2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

public class LengthActivity extends AppCompatActivity {

    Spinner lengthSpinner1;
    Spinner lengthSpinner2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_length);

        //Create spinners
        //Spinner 1
        lengthSpinner1 = (Spinner) findViewById(R.id.lengthSpinner1);
        ArrayAdapter<CharSequence> lengthAdapter1 = ArrayAdapter.createFromResource(this,
                R.array.length_array, android.R.layout.simple_spinner_item);
        lengthAdapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        lengthSpinner1.setAdapter(lengthAdapter1);

        //Spinner 2
        lengthSpinner2 = (Spinner) findViewById(R.id.lengthSpinner2);
        ArrayAdapter<CharSequence> lengthAdapter2 = ArrayAdapter.createFromResource(this,
                R.array.length_array, android.R.layout.simple_spinner_item);
        lengthAdapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        lengthSpinner2.setAdapter(lengthAdapter2);
    }

    public void submitLength(View view){
    // Calculate length
    }
}
