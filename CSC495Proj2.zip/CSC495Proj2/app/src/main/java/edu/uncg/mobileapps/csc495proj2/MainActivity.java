package edu.uncg.mobileapps.csc495proj2;

import android.graphics.Typeface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Typeface fontfamily = Typeface.createFromAsset(getAssets(), "fonts/fontawesome.ttf");

        //TIme Icon
        TextView timeIcon = (TextView) findViewById(R.id.time_button);
        timeIcon.setTypeface(fontfamily);
    }
}
