package edu.uncg.mobileapps.csc495proj2;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class NameActivity extends AppCompatActivity {

    EditText nameInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_name);
        checkPref();
        nameInput = (EditText) findViewById(R.id.editTextName);
    }

    public void startMain(View view) {
        SharedPreferences sharedPrefs = getSharedPreferences("univertNamePref", Context.MODE_PRIVATE);
        SharedPreferences.Editor ed;
                if (nameInput.getText().toString().equals("")) {
                    Toast.makeText(NameActivity.this, "Name cannot be empty!", Toast.LENGTH_SHORT).show();
                }else{
                ed = sharedPrefs.edit();
                //Indicate that the default shared prefs have been set
                ed.putString("name", nameInput.getText().toString());
                ed.apply();
                Intent nameIntent = new Intent(this, MainActivity.class);
                startActivity(nameIntent);
                }
            }

    public void checkPref() {
        SharedPreferences sharedPrefs = getSharedPreferences("univertNamePref", Context.MODE_PRIVATE);
        SharedPreferences.Editor ed;
        if (sharedPrefs.contains("name")) {
            Intent nameIntent = new Intent(this, MainActivity.class);
            startActivity(nameIntent);
            String name = sharedPrefs.getString("name", "");
            Toast.makeText(NameActivity.this, "Welcome back " + name, Toast.LENGTH_SHORT).show();
        }
    }
}
