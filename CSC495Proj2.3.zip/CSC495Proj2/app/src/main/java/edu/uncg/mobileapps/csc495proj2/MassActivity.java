package edu.uncg.mobileapps.csc495proj2;

import android.content.Context;
import android.content.SharedPreferences;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import javax.measure.Measure;
import javax.measure.converter.UnitConverter;
import javax.measure.unit.Unit;

import static javax.measure.unit.NonSI.FOOT;
import static javax.measure.unit.NonSI.INCH;
import static javax.measure.unit.NonSI.MILE;
import static javax.measure.unit.NonSI.OUNCE;
import static javax.measure.unit.NonSI.POUND;
import static javax.measure.unit.NonSI.TON_US;
import static javax.measure.unit.NonSI.YARD;
import static javax.measure.unit.SI.CENTIMETER;
import static javax.measure.unit.SI.GRAM;
import static javax.measure.unit.SI.KILOGRAM;
import static javax.measure.unit.SI.KILOMETER;
import static javax.measure.unit.SI.METER;
import static javax.measure.unit.SI.MICRO;
import static javax.measure.unit.SI.MILLIMETER;

public class MassActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener, SensorEventListener {
    Spinner massSpinner1;
    Spinner massSpinner2;
    String spinner1Value;
    String spinner2Value;
    String answer;

    private float lastX, lastY, lastZ;
    private SensorManager sensorManager;
    private Sensor accelerometer;
    private float deltaX = 0;
    private float deltaY = 0;
    private float deltaZ = 0;
    private float shakeThreshold = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mass);

        //Create spinners
        //Spinner 1
        massSpinner1 = (Spinner) findViewById(R.id.massSpinner1);
        ArrayAdapter<CharSequence> massAdapter1 = ArrayAdapter.createFromResource(this,
                R.array.mass_array, android.R.layout.simple_spinner_item);
        massAdapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        massSpinner1.setAdapter(massAdapter1);

        //Spinner 2
        massSpinner2 = (Spinner) findViewById(R.id.massSpinner2);
        ArrayAdapter<CharSequence> massAdapter2 = ArrayAdapter.createFromResource(this,
                R.array.mass_array, android.R.layout.simple_spinner_item);
        massAdapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        massSpinner2.setAdapter(massAdapter2);

        // Init sensorManager
        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        if (sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) != null) {
            // success! we have an accelerometer
            accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
            sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_NORMAL);
            shakeThreshold = accelerometer.getMaximumRange() / 2;
        } else {
            // fail we dont have an accelerometer!
        }
    }

    public void submitMass(View view){
        spinner1Value = massSpinner1.getSelectedItem().toString();
        spinner2Value = massSpinner2.getSelectedItem().toString();

        EditText editTextValue1 = (EditText) findViewById(R.id.editText);
        CharSequence editValue1 = editTextValue1.getText();

        float editValueFloat = Float.parseFloat(editValue1.toString());

        Unit unit1 = getUnit(spinner1Value);
        Unit unit2 = getUnit(spinner2Value);

        UnitConverter value = unit1.getConverterTo(unit2);
        double answer = value.convert(Measure.valueOf(editValueFloat, unit1).doubleValue(unit1));
        String answerString = String.valueOf(answer);

        TextView answerView = (TextView) findViewById(R.id.answerViewMass);
        answerView.setText(answerString);
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        parent.getItemAtPosition(position);
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        deltaX = Math.abs(lastX - event.values[0]);
        deltaY = Math.abs(lastY - event.values[1]);
        deltaZ = Math.abs(lastZ - event.values[2]);

        if (deltaX < 2)
            deltaX = 0;
        if (deltaY < 2)
            deltaY = 0;
        if (deltaZ < 2)
            deltaZ = 0;

        lastX = event.values[0];
        lastY = event.values[1];
        lastZ = event.values[2];
        shake();
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }

    @Override
    protected void onResume() {
        super.onResume();
        sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_NORMAL);
    }

    @Override
    protected void onPause() {
        super.onPause();
        sensorManager.unregisterListener(this);
    }

    public void shake() {
        if ((deltaX > shakeThreshold) || (deltaY > shakeThreshold) || (deltaZ > shakeThreshold)) {
            TextView answerView = (TextView) findViewById(R.id.answerViewMass);
            answerView.setText("");

            EditText editTextValue1 = (EditText) findViewById(R.id.editText);
            editTextValue1.getText().clear();
        }
    }

    public void setMassSharedPref(){

        SharedPreferences sharedPrefs = getSharedPreferences("univertMassPref", Context.MODE_PRIVATE);
        SharedPreferences.Editor ed;
        if(!sharedPrefs.contains("initialized")){
            ed = sharedPrefs.edit();


            //Indicate that the default shared prefs have been set
            ed.putBoolean("initialized", true);
            ed.commit();
        }else{
            //set other crap;
            Toast.makeText(MassActivity.this, "Set Pref!", Toast.LENGTH_SHORT).show();
        }
    }

    public Unit getUnit(String spinnerValue){
        Unit unit = null;

        switch(spinnerValue){
            case "Kilogram": unit = KILOGRAM;
                break;
            case "Gram": unit = GRAM;
                break;
            case "Milligram": unit = GRAM.divide(1000L);
                break;
            case "Microgram": unit = GRAM.divide(1000L).divide(1000L);
                break;
            case "Ton": unit = TON_US;
                break;
            case "Pound": unit = POUND;
                break;
            case "Ounce": unit = OUNCE;
                break;
        }
        return unit;
    }
}
